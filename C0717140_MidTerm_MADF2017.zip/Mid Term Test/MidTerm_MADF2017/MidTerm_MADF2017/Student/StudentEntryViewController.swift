//
//  StudentEntryViewController.swift
//  MidTerm_MADF2017
//
//  Created by moxDroid on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Student ID :
//  Student Name :

import UIKit

class StudentEntryViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var tfStudentID: UITextField!
    
    @IBOutlet weak var tfStudentname: UITextField!
    
    
    @IBOutlet weak var tfEmail: UITextField!
    
    @IBOutlet weak var tfDOB: UITextField!
    
    
    @IBOutlet weak var tfmarks: UITextField!
    
    
    @IBOutlet weak var tfM1: UITextField!
    
    @IBOutlet weak var tfM2: UITextField!
    
    @IBOutlet weak var tfM3: UITextField!
    
    @IBOutlet weak var tfM4: UITextField!
    
    @IBOutlet weak var tfM5: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = false
        
        self.navigationItem.setHidesBackButton(true, animated:true);
        
        let btnLogout = UIBarButtonItem(title: "LOGOUT", style: .plain, target: self, action: #selector(Logout))
        self.navigationItem.rightBarButtonItem  = btnLogout
//        let button1 = UIBarButtonItem(image: UIImage(named: "imagename"), style: .plain, target: self, action: Selector("action")) // action:#selector(Class.MethodName) for swift 3
//        self.navigationItem.rightBarButtonItem  = button1

        // Do any additional setup after loading the view.
    }

    @objc func Logout(){
        
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let LoginVC = storyBoard.instantiateViewController(withIdentifier: "LoginVC") as! LoginViewController
        self.show(LoginVC, sender: self)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnSubmitTapped(_ sender: UIButton) {
        
        let ObjStudent = Student()
        
        ObjStudent.StudentName = tfStudentname.text
        ObjStudent.StudentID = Int(tfStudentID.text!)
        ObjStudent.Email = tfEmail.text
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-mm-yyyy"
        //dateFormatter.timeZone = TimeZone(abbreviation: "GMT+0:00")
        ObjStudent.birthDate = dateFormatter.date(from: tfDOB.text!)
        ObjStudent.M1 = Int(tfM1.text!)
        ObjStudent.M2 = Int(tfM2.text!)
        ObjStudent.M3 = Int(tfM3.text!)
        ObjStudent.M4 = Int(tfM4.text!)
        ObjStudent.M5 = Int(tfM5.text!)
       // ObjStudent.Marks = [tfmarks.text]
        
     //  ObjStudent.addStudentData(std: ObjStudent)
       
      //  ObjStudent.add(Int(tfM1.text!)!, Int(tfM2.text!)!, Int(tfM3.text!)!, Int(tfM4.text!)!, Int(tfM5.text!)!)
        
        let flag = Student.addStudentData(std: ObjStudent)
        if flag == true{
            print("Student Data Saved Succesfully!")
        }else{
            print("Possible Duplication Error!!")
        }
        
       
        
        
        
    }
    
    
    
   
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return true
    }
    

    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
