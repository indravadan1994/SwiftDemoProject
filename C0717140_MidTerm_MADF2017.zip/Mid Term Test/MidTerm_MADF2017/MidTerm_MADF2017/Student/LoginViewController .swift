//
//  ViewController.swift
//  MidTerm_MADF2017
//
//  Created by moxDroid on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Student ID :
//  Student Name :

import UIKit

class LoginViewController : UIViewController,UITextFieldDelegate {

    
    @IBOutlet weak var tfUsername: UITextField!
    
    
    @IBOutlet weak var tfPassword: UITextField!
    
    let sharedPreference = UserDefaults.standard
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewWillAppear(_ animated: Bool) {
         self.navigationController?.isNavigationBarHidden = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnLogintapped(_ sender: UIButton) {
        
        sharedPreference.set("C0717140" , forKey: "userName")
        sharedPreference.set("indravadan", forKey: "Password")
        
        if (tfUsername.text == (sharedPreference.value(forKey: "userName") as? String) && tfPassword.text == (sharedPreference.value(forKey: "Password") as? String)){
        
      
            
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
            let StudentEntryVC = storyBoard.instantiateViewController(withIdentifier: "StudentEntryVC") as! StudentEntryViewController
            self.show(StudentEntryVC, sender: sender)
            
            
            
        
      }
        else
        {
            
           
            let alert = UIAlertController(title: "Alert", message: "Username or Password is Incorrect!", preferredStyle: .alert)

            let action1 = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(action1)

            let action2 = UIAlertAction(title: "Cancel", style: .destructive, handler: nil)
            alert.addAction(action2)

        
            
            self.present(alert, animated: true, completion: nil)
        }
        
       
            
       
      
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return true
    }
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        
        
        return true
    }
    
    
}

