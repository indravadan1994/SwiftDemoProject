//
//  Student.swift
//  MidTerm_MADF2017
//
//  Created by moxDroid on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Student ID :
//  Student Name :

import Foundation

class Student{
    
    var StudentID : Int!
    var StudentName : String!
    var Email : String!
    var birthDate : Date!
    var M1 : Int!
    var M2 : Int!
    var M3 : Int!
    var M4 : Int!
    var M5 : Int!
    //var Marks : Array<Int>!
    
    static var studentData = [Int : Student]()
    
    init(){
        
        StudentID = 0
        StudentName = ""
        Email = ""
        birthDate = Date()
        M1 = 0
        M2 = 0
        M3 = 0
        M4 = 0
        M5 = 0
       // Marks = [Int]()
        
    }
    
    init(_ studentID : Int, _ studentName : String, _ email : String, _bdate : Date, _ m1 : Int, _ m2 : Int,_ m3 : Int,_ m4 : Int,_ m5 : Int) {
        
        self.StudentID = studentID
        self.StudentName = studentName
        self.Email = email
        self.birthDate = _bdate
        self.M1 = m1
        self.M2 = m2
        self.M3 = m3
        self.M4 = m4
        self.M5 = m5
        
       // self.Marks = _marks
    }
    
    
   static func addStudentData (std : Student) -> Bool{
    
    if self.studentData[std.StudentID] == nil{
    self.studentData[std.StudentID] = std
        return true
        
        }
    return false
    }
    
    static func getAllStudentData() -> [Int:Student] {
        return studentData
    }
    
    
    func add(_ m1:Int,_ m2:Int,_ m3:Int,_ m4:Int,_ m5:Int) -> Int{
        
        return m1+m2+m3+m4+m5
        
    }
    
    
    static func CalculateTotal (std1 : Student) -> Int{
        
        
        
        
        return 0
    }
    
}
